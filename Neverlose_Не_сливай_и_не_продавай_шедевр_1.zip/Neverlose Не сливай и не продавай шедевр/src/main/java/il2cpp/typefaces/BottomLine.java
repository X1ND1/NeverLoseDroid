package il2cpp.typefaces;

import il2cpp.Utils;
import il2cpp.typefaces.SwipeListener;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup.LayoutParams;
import android.widget.Toast;

public class BottomLine {
	Context context;
	
	public LinearLayout mainlayout, line;
	public SwipeListener swipes;
	
	FrameLayout parentBox;
	
	public Callback callback;
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public static interface Callback {
		public void onSwipe();
	}
	
	public void addOnScreen() {
		parentBox = new FrameLayout(context);

		//parentBox.setOnTouchListener(handleMotionTouch);
		WindowManager wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0, 0,
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
		
		wmManager.addView(parentBox, wmParams);
		parentBox.addView(mainlayout);
	}
	
	public void swipe() {
		if (callback != null) {callback.onSwipe();}
	}
	
	public BottomLine(Context ctx) {
		context = ctx;
		
		swipes = new SwipeListener(context) {
			public void onSwipeUp() {
				swipe();
			}
		};
		
		mainlayout = new LinearLayout(context);
		{ // Main layout background
			mainlayout.setLayoutParams(new LayoutParams(Utils.dp(context, 400), Utils.dp(context, 20)));
			mainlayout.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
			
			line = new LinearLayout(context);
			{ // Line open design
				GradientDrawable grad = new GradientDrawable();
				grad.setColor(Color.argb(160, 255, 255, 255));
				grad.setCornerRadius(1000f);
				
				line.setBackgroundDrawable(grad);
				line.setElevation(15f);
				
				mainlayout.setPadding(5,0,5,10);
				mainlayout.addView(line, -1, Utils.dp(context, 5));
			}
		}
		
		mainlayout.setOnTouchListener(swipes);
		line.setOnTouchListener(swipes);
		addOnScreen();
	}
}
