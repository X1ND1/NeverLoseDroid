package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import il2cpp.typefaces.Switch2;
import androtrainer.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.Toolbar.LayoutParams;
import java.util.ArrayList;
import android.view.View.OnClickListener;
import il2cpp.typefaces.ImagesList;

class ColorList {
	public static int get_colorWhite() {
		return Color.WHITE;
	}
	
	public static int get_colorLeft() {
		return Color.parseColor("#1B1C1B");
	}
	
	public static int get_colorBlue() {
		return Color.parseColor("#0F9FDE");
	}
	
	public static int get_colorBlack() {
		return Color.parseColor("#080808");
	}

	public static int get_colorGray() {
		return Color.parseColor("#363D40");
	}
		
	public static int get_colorHeader() {
		return Color.parseColor("#0B0A0F");
	}
	
}

class PageButton extends LinearLayout{
	Context context;
	
	public LinearLayout line;
	public ImageView icon;
	public TextView title;
	
	public boolean isCheck = false;
	
	public void setChecked(boolean chck) {
		isCheck = chck;
		GradientDrawable grad = new GradientDrawable();
		
		grad.setCornerRadius(15);
		if (isCheck) {
			grad.setColor(ColorList.get_colorGray());
			
		}
		line.setBackgroundDrawable(grad);
	}
	
	public void setOnClick(OnClickListener clck) {
		setOnClickListener(clck);
	}
	
	public PageButton(Context ctx, String name, String ic) {
		super(ctx);
		context = ctx;
		
		setGravity(Gravity.CENTER);
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 25)));
		
		line = new LinearLayout(context);
		line.setOrientation(LinearLayout.HORIZONTAL);
		{ // Line
			line.setGravity(Gravity.CENTER);
			icon = new ImageView(context);
			{ // Icon
				icon.setPadding(15,5,0,5);
				icon.setColorFilter(ColorList.get_colorBlue());
				Utils.SetAssets(context, icon, ic);
			}
			
			title = new TextView(context);
			{
				title.setText(name);
				title.setTextSize(10f);
				title.setTextColor(ColorList.get_colorWhite());
				title.setTypeface(Utils.font(context));
				title.setGravity(Gravity.CENTER_VERTICAL);
				title.setPadding(15, 0, 0, 0);
			}
			
			line.addView(icon, Utils.dp(context, 20), Utils.dp(context, 30));
			line.addView(title, Utils.dp(context, 65), -1);
		}
		
		addView(line, Utils.dp(context, 90), -1);
		
		setChecked(false);
	}
}

public class Menu
{
	protected int WIDTH,HEIGHT;
   	
	protected Context context;
	protected FrameLayout parentBox;
	protected LinearLayout menulayout, leftlayout, rightlayout, mainlayout;
	protected ImageView logoView;
	
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	public boolean isShow = true;
	
	protected ArrayList<PageButton> pbutts = new ArrayList<>();
	protected ArrayList<ComponentBlock> blocks = new ArrayList<>();
	protected ArrayList<LinearLayout> pages = new ArrayList<>();
	
	protected void init(Context context) {
		
		this.context = context;
		parentBox = new FrameLayout(context);

		parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0, 
			0,
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_FULLSCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}
	
	public int dpi(int i) {
		return Utils.dp(context, i);
	}
	
	public int newPage(String name, String src) {
		final int pageid = pbutts.size();
		PageButton page = new PageButton(context, name, src);
		pbutts.add(page);
		
		LinearLayout pagelayout = new LinearLayout(context);
		pagelayout.setOrientation(LinearLayout.VERTICAL);
		pagelayout.setPadding(15,15,15,15);
		mainlayout.addView(pagelayout, -1, -1);
		pagelayout.setVisibility(View.GONE);
		
		pages.add(pagelayout);
		
		page.setOnClick(new OnClickListener() {
			public void onClick(View v) {
				showPage(pageid);
			}
		});
		
		leftlayout.addView(page);
		leftlayout.addView(new LinearLayout(context), -1, Utils.dp(context, 4));
		return pageid;
	}
	
	public void showPage(int i) {
		for (PageButton butt: pbutts) {
			butt.setChecked(false);
		}
		pbutts.get(i).setChecked(true);
		Utils.anim(pbutts.get(i), 300);
		
		for (LinearLayout page: pages) {
			page.setVisibility(View.GONE);
		}
		pages.get(i).setVisibility(View.VISIBLE);
		Utils.anim(pages.get(i), 300);
	}
	
	public void showMenu() {
		isShow = true;
		parentBox.addView(menulayout, WIDTH, HEIGHT);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));
		scaleDown.setDuration(350);
		scaleDown.start();
	}

	public void hideMenu() {
		isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
				public void run() {
					parentBox.removeAllViews();
				}
			}, 350);
	}
	
	public void newSwitch(int pageid, String text, Switch2.Callback call) {
		Switch2 butt = new Switch2(context, text);
		blocks.get(pageid).main.addView(butt);
		butt.setCallback(call);
	}
	
	public void newSlider(int pageid, String text, int max, int curr, WeaveSeekBar.Callback call) {
		WeaveSeekBar seek = new WeaveSeekBar(context, text, max, curr);
		blocks.get(pageid).main.addView(seek);
		seek.setCallback(call);
	}
	
	public void newText(String text) {
		TextView title = new TextView(context);
		title.setText(text);
		title.setTextColor(ColorList.get_colorGray());
		title.setTextSize(10);
		title.setPadding(25, 0, 0, 0);
		title.setGravity(Gravity.CENTER_VERTICAL);
		title.setTypeface(Utils.font(context));
		
		leftlayout.addView(title, -1, Utils.dp(context, 15));
	}
	
	public Menu(Context context)
	{
		init(context);

		WIDTH = dpi(400);
		HEIGHT = dpi(340);
		
		menulayout = new LinearLayout(context);
		menulayout.setOrientation(LinearLayout.HORIZONTAL);
		
		leftlayout = new LinearLayout(context);
		leftlayout.setOrientation(LinearLayout.VERTICAL);
		{ // Left panel
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(ColorList.get_colorLeft());
			grad.setCornerRadius(10);
			
			leftlayout.setBackgroundDrawable(grad);
			
			menulayout.addView(leftlayout, dpi(100), -1);
			
			logoView = new ImageView(context);
			{ // Logo
				//logoView.setPadding(3,3,3,3);
				logoView.setPadding(10,0,10,0);
				Utils.SetAssets(context, logoView, "logo.png");
				leftlayout.addView(logoView, -1, dpi(40));
			}
			
			LinearLayout expand = new LinearLayout(context);
			{
				LinearLayout line = new LinearLayout(context);
				line.setBackgroundColor(ColorList.get_colorGray());
				
				expand.addView(line, -1, dpi(1));
				expand.setGravity(Gravity.TOP);
				expand.setPadding(20, 0, 20, 0);
				
				leftlayout.addView(expand, -1, dpi(20));
			}
			
		}
		
		rightlayout = new LinearLayout(context);
		{
			menulayout.addView(rightlayout, new LayoutParams(-1, -1, 1));
		}
		
		mainlayout = new LinearLayout(context);
		{ // Main
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(ColorList.get_colorBlack());
			grad.setCornerRadii(new float[]{0, 0, 10, 10, 10, 10, 0, 0});
			
			mainlayout.setBackgroundDrawable(grad);
			mainlayout.setPadding(15,15,15,15);
			rightlayout.addView(mainlayout, -1, -1);
		}
		
		{
		}
		
		BottomLine lineOpen = new BottomLine(context);
		lineOpen.setCallback(new BottomLine.Callback() {
			public void onSwipe() {
				if (isShow) {
					hideMenu();
				} else {
					showMenu();
				}
			}
		});
		
		parentBox.addView(menulayout, WIDTH, HEIGHT);
		wmManager.addView(parentBox, wmParams);
	}

	public int newBlock(int pageid, String[] names) {
		final int blockid = blocks.size();

		LinearLayout blockline = new LinearLayout(context);
		blockline.setOrientation(LinearLayout.HORIZONTAL);

		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			ComponentBlock block = new ComponentBlock(context, name);
			blocks.add(block);

			if (names.length > 1) {
				if ((i != 0)) {
					LinearLayout expand = new LinearLayout(context);
					blockline.addView(expand, dpi(5), -1);
				}
			}
			blockline.addView(block, new LinearLayout.LayoutParams(-1, -1, 1));

		}
		pages.get(pageid).addView(blockline, -1, -1);
		return blockid;
	}
	

	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					/*if (isIconVisible && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}*/
					break;
			}
			return true;
		}
	};
	public static interface ibt {
        void OnWrite();
    }
	
	public static interface iit {
        void OnWrite(int i);
    }
	
	private int convertDipToPixels(int i) {
        return (int) ((((float) i) * context.getResources().getDisplayMetrics().density) + 0.5f);
    }
}
